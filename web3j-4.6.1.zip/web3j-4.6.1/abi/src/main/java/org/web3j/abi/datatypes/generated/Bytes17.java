package org.web3j.abi.datatypes.generated;

import org.web3j.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use org.web3j.codegen.AbiTypesGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes17 extends Bytes {
    public static final Bytes17 DEFAULT = new Bytes17(new byte[17]);

    public Bytes17(byte[] value) {
        super(17, value);
    }
}
