package org.web3j.abi.datatypes.generated;

import org.web3j.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use org.web3j.codegen.AbiTypesGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes3 extends Bytes {
    public static final Bytes3 DEFAULT = new Bytes3(new byte[3]);

    public Bytes3(byte[] value) {
        super(3, value);
    }
}
