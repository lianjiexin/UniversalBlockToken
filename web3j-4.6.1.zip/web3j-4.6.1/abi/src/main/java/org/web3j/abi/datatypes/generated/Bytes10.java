package org.web3j.abi.datatypes.generated;

import org.web3j.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use org.web3j.codegen.AbiTypesGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes10 extends Bytes {
    public static final Bytes10 DEFAULT = new Bytes10(new byte[10]);

    public Bytes10(byte[] value) {
        super(10, value);
    }
}
