All resources should be compiled with:

solc <contract>.sol --bin --abi --optimize -o build/

Or you can use the Solidity browser at https://ethereum.github.io/browser-solidity/.
