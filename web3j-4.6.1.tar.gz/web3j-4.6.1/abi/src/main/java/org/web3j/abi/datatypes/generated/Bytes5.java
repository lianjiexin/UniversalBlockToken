package org.web3j.abi.datatypes.generated;

import org.web3j.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use org.web3j.codegen.AbiTypesGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes5 extends Bytes {
    public static final Bytes5 DEFAULT = new Bytes5(new byte[5]);

    public Bytes5(byte[] value) {
        super(5, value);
    }
}
