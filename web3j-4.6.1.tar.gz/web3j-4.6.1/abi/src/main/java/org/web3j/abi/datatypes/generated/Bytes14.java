package org.web3j.abi.datatypes.generated;

import org.web3j.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use org.web3j.codegen.AbiTypesGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes14 extends Bytes {
    public static final Bytes14 DEFAULT = new Bytes14(new byte[14]);

    public Bytes14(byte[] value) {
        super(14, value);
    }
}
